# AgriTrack — Model Architecture

本包提供 AMTD 与 Paddy 共用的 AgriTrack 自定义神经网络结构，使用 PyTorch 实现。
模型接收已构造的张量，返回逐位置的 logits。所有构造参数均须由调用者显式提供，无预设取值。

## 模型

- `BaseBiLSTM`：双向 LSTM → LayerNorm → Dropout → 线性分类头。
- `RTFSRCTransformer`：输入线性投影 → 后置归一化 Transformer 编码器 → 标量线性投影。
  编码器使用有效位置掩码，不包含位置编码。

方向风险组件使用 scikit-learn 的 `RandomForestClassifier`（FTR）和
`ExtraTreesClassifier`（RTF）。本包仅包含上述自定义神经网络结构及其接口。

## 使用

在本目录安装依赖：

```sh
python -m pip install -r requirements.txt
```

在本目录或将本目录加入 Python 模块搜索路径后导入：

```python
from agritrack import BaseBiLSTM, RTFSRCTransformer
```

| 接口 | 输入 | 输出 |
| --- | --- | --- |
| `BaseBiLSTM.forward(x, lengths)` | `x: [batch, time, input_dim]`；`lengths: [batch]` | `[batch, time, num_classes]` logits |
| `RTFSRCTransformer.forward(x, valid_mask=valid_mask)` | `x: [batch, time, input_dim]`；布尔掩码 `[batch, time]` | `[batch, time]` logits |

`lengths` 为每条序列的有效长度，必须为正且不超过输入时间轴长度，填充值位于有效位置之后。
`valid_mask` 中 `True` 表示有效位置；每条序列必须至少包含一个有效位置。
调用者须忽略填充位置的输出；输出未经概率变换。
构造参数名称与类型见模型类的 `__init__` 签名；`d_model` 必须能够被 `nhead` 整除。

## 文件

- `agritrack/base.py`：基础双向循环网络。
- `agritrack/src_transformer.py`：SRC Transformer。
- `agritrack/__init__.py`：模型导出接口。
