# AgriTrack — Model Architecture

本包提供 AMTD 与 Paddy 共用的 AgriTrack 模型结构，使用 PyTorch 和 scikit-learn 实现。
神经网络接收已构造的张量，返回逐位置的 logits；方向风险模型接收特征矩阵，返回错误概率。
所有公开的构造配置均须由调用者显式提供，无预设取值。

## 模型

- `BaseBiLSTM`：双向 LSTM → LayerNorm → Dropout → 线性分类头。
- `RTFSRCTransformer`：输入线性投影 → 后置归一化 Transformer 编码器 → 标量线性投影。
  编码器使用有效位置掩码，不包含位置编码。
- FTR 风险模型：`RandomForestClassifier`，估计 FTR 方向的基础预测错误概率。
- RTF 风险模型：`ExtraTreesClassifier`，估计 RTF 方向的基础预测错误概率。

`build_risk_model` 根据方向构建对应的树集成模型。
`DirectionalRiskModels` 是整理双向调用接口的轻量容器，持有两个独立模型并路由预测。
`positive_probability` 按类别标签定位错误类的概率列。
树算法由 scikit-learn 实现，构建和方向预测接口位于本包的 `risk.py`。

## 使用

在本目录安装依赖：

```sh
python -m pip install -r requirements.txt
```

在本目录或将本目录加入 Python 模块搜索路径后导入：

```python
from agritrack import (
    BaseBiLSTM,
    RTFSRCTransformer,
    DirectionalRiskModels,
    build_risk_model,
    positive_probability,
)
```

| 接口 | 输入 | 输出 |
| --- | --- | --- |
| `BaseBiLSTM.forward(x, lengths)` | `x: [batch, time, input_dim]`；`lengths: [batch]` | `[batch, time, num_classes]` logits |
| `RTFSRCTransformer.forward(x, valid_mask=valid_mask)` | `x: [batch, time, input_dim]`；布尔掩码 `[batch, time]` | `[batch, time]` logits |
| `DirectionalRiskModels.predict_ftr(features)` | FTR 特征矩阵 `[samples, features]` | `[samples]` 错误概率 |
| `DirectionalRiskModels.predict_rtf(features)` | RTF 特征矩阵 `[samples, features]` | `[samples]` 错误概率 |

`lengths` 为每条序列的有效长度，必须为正且不超过输入时间轴长度，填充值位于有效位置之后。
`valid_mask` 中 `True` 表示有效位置；每条序列必须至少包含一个有效位置。
调用者须忽略神经网络填充位置的输出；神经网络输出未经概率变换。
构造参数名称与类型见模型类的 `__init__` 签名；`d_model` 必须能够被 `nhead` 整除。

`build_risk_model` 返回未拟合的原生 scikit-learn 分类器，构造配置见函数签名。
两个方向分别接收各自的特征矩阵；预测前须由调用者准备已拟合的对应模型。
FTR 接收基础模型判为 Road 的对应特征，估计真实类别为 Field 的错误风险；
RTF 接收基础模型判为 Field 的对应特征，估计真实类别为 Road 的错误风险。
调用者须事先完成对应方向的筛选和特征构造；两向的特征语义不同。
风险输出是错误标签 `1` 的概率，不是神经网络 logits，也不是最终修正标签。
接口之外的估计器行为遵循所安装 scikit-learn 的库默认行为。
模型构建与预测接口不执行特征生成、阈值决策或完整实验流程。

## 文件

- `agritrack/base.py`：基础双向循环网络。
- `agritrack/src_transformer.py`：SRC Transformer。
- `agritrack/risk.py`：双方向风险模型构建、概率计算和方向路由。
- `agritrack/__init__.py`：模型导出接口。
