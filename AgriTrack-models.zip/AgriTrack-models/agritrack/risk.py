"""Directional tree ensembles and error-probability outputs for AgriTrack."""

import numpy as np
from sklearn.ensemble import ExtraTreesClassifier, RandomForestClassifier
from sklearn.utils.validation import check_is_fitted


def build_risk_model(
    direction: str,
    *,
    n_estimators: int,
    criterion: str,
    max_depth: int | None,
    min_samples_leaf: int | float,
    max_features: int | float | str | None,
    bootstrap: bool,
    class_weight: dict | str | None,
    n_jobs: int | None,
) -> RandomForestClassifier | ExtraTreesClassifier:
    """Construct an unfitted tree ensemble for the requested direction.

    FTR uses a random forest; RTF uses an extremely randomized forest.
    All exposed construction settings must be supplied by the caller.
    """
    if direction == "FTR":
        model_type = RandomForestClassifier
    elif direction == "RTF":
        model_type = ExtraTreesClassifier
    else:
        raise ValueError("direction must be 'FTR' or 'RTF'")

    return model_type(
        n_estimators=n_estimators,
        criterion=criterion,
        max_depth=max_depth,
        min_samples_leaf=min_samples_leaf,
        max_features=max_features,
        bootstrap=bootstrap,
        class_weight=class_weight,
        n_jobs=n_jobs,
    )


def positive_probability(
    model: RandomForestClassifier | ExtraTreesClassifier,
    features: np.ndarray,
) -> np.ndarray:
    """Return the probability of error label 1 for each feature row.

    The estimator must already be fitted to error labels. The positive column
    is located by its class label rather than its position in the output.
    """
    check_is_fitted(model, attributes=["classes_"])
    classes = np.asarray(model.classes_)
    if classes.ndim != 1:
        raise ValueError("A single-output risk classifier is required")
    matches = np.flatnonzero(classes == 1)
    if matches.size != 1:
        raise ValueError("The risk classifier must contain exactly one error label 1")
    return model.predict_proba(features)[:, int(matches[0])].astype(
        np.float64, copy=False
    )


class DirectionalRiskModels:
    """Keep FTR and RTF risk estimators separate and route their predictions.

    The caller supplies features already prepared for the relevant direction.
    FTR applies to base predictions of Road and estimates a true Field label;
    RTF applies to base predictions of Field and estimates a true Road label.
    The inputs may contain different rows and use different feature construction.
    """

    def __init__(
        self,
        *,
        ftr_model: RandomForestClassifier,
        rtf_model: ExtraTreesClassifier,
    ) -> None:
        if not isinstance(ftr_model, RandomForestClassifier):
            raise TypeError("ftr_model must be a RandomForestClassifier")
        if not isinstance(rtf_model, ExtraTreesClassifier):
            raise TypeError("rtf_model must be an ExtraTreesClassifier")
        self.ftr_model = ftr_model
        self.rtf_model = rtf_model

    def predict_ftr(self, features: np.ndarray) -> np.ndarray:
        """Return FTR error probabilities with shape [samples]."""
        return positive_probability(self.ftr_model, features)

    def predict_rtf(self, features: np.ndarray) -> np.ndarray:
        """Return RTF error probabilities with shape [samples]."""
        return positive_probability(self.rtf_model, features)
