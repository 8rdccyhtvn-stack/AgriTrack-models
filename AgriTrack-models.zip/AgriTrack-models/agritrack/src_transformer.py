"""Transformer model for per-position scalar logits."""

import torch
from torch import nn


class RTFSRCTransformer(nn.Module):
    """Input projection, Transformer encoder, and scalar output projection."""

    def __init__(
        self,
        *,
        input_dim: int,
        d_model: int,
        nhead: int,
        dim_feedforward: int,
        num_layers: int,
        dropout: float,
    ) -> None:
        super().__init__()
        self.input_projection = nn.Linear(input_dim, d_model)
        layer = nn.TransformerEncoderLayer(
            d_model=d_model,
            nhead=nhead,
            dim_feedforward=dim_feedforward,
            dropout=dropout,
            batch_first=True,
            norm_first=False,
        )
        self.encoder = nn.TransformerEncoder(
            layer,
            num_layers=num_layers,
            enable_nested_tensor=False,
        )
        self.output_projection = nn.Linear(d_model, 1)

    def forward(self, x: torch.Tensor, valid_mask: torch.Tensor) -> torch.Tensor:
        """Map (batch, time, input_dim) to (batch, time) logits.

        ``valid_mask`` is a Boolean (batch, time) tensor with True at valid
        positions. Each sequence must contain a valid position.
        Consumers must mask padded outputs.
        """
        h = self.input_projection(x)
        h = self.encoder(h, src_key_padding_mask=~valid_mask)
        return self.output_projection(h).squeeze(-1)
