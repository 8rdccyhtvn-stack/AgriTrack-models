"""Bidirectional recurrent model for per-position classification."""

import torch
from torch import nn
from torch.nn.utils.rnn import pack_padded_sequence, pad_packed_sequence


class BaseBiLSTM(nn.Module):
    """Bidirectional LSTM followed by normalization and a classification head."""

    def __init__(
        self,
        *,
        input_dim: int,
        hidden_size: int,
        num_layers: int,
        lstm_dropout: float,
        head_dropout: float,
        num_classes: int,
    ) -> None:
        super().__init__()
        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_size,
            num_layers=num_layers,
            batch_first=True,
            bidirectional=True,
            dropout=lstm_dropout,
        )
        self.norm = nn.LayerNorm(2 * hidden_size)
        self.dropout = nn.Dropout(head_dropout)
        self.classifier = nn.Linear(2 * hidden_size, num_classes)

    def forward(self, x: torch.Tensor, lengths: torch.Tensor) -> torch.Tensor:
        """Map (batch, time, input_dim) to (batch, time, num_classes).

        ``lengths`` contains each sequence's valid length. Inputs are padded
        after their valid positions; consumers must mask padded outputs.
        """
        packed = pack_padded_sequence(
            x,
            lengths.detach().cpu(),
            batch_first=True,
            enforce_sorted=False,
        )
        packed_out, _ = self.lstm(packed)
        out, _ = pad_packed_sequence(
            packed_out,
            batch_first=True,
            total_length=x.size(1),
        )
        return self.classifier(self.dropout(self.norm(out)))
